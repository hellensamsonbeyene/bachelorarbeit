# Bachelorarbeit



## Backend (localhost:8080)

Starten Sie SpringbootChatbotApplication 

## Frontend (localhost:3000)

Starten Sie im Ordner "bachelorarbeit/react-gui" das Programm mit folgendem Befehl

npm start

